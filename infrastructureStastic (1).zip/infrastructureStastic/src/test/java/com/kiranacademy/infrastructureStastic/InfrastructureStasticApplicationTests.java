package com.kiranacademy.infrastructureStastic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfrastructureStasticApplicationTests {

	@Test
	void contextLoads() {
	}

}
